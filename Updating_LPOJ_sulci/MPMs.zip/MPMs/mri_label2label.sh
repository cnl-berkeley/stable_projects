# Set subject directory (assumes fsaverage surface is also located there)
SUBJECTS_DIR=<edit path>/subjects

# Choose subject(s) to project label to
TRG_SUBS=''

# Set label directory to location of probability maps
PROB_MAP_DIR=<edit path>/MPMs

# LPC/LPOJ sulci
PROB_MAPS='aipsJ cSTS1 cSTS2 cSTS3 IPS-PO IPS lTOS mTOS pips sB slocs-d slocs-v SmgS SPS STS'

# Run mri_label2label to project to new surface
for TRG_SUB in $TRG_SUBS;
do

for PROB_MAP in $PROB_MAPS;
do

## left hemisphere
mri_label2label --srcsubject $SUBJECTS_DIR/fsaverage --srclabel $PROB_MAP_DIR/lh.HCP_LPC_PROB_MPM_0.20_${PROB_MAP}.label --trgsubject $SUBJECTS_DIR/$TRG_SUB --trglabel $SUBJECTS_DIR/$TRG_SUB/label/lh.${PROB_MAP}_MPM.label --regmethod surface

## right hemisphere
mri_label2label --srcsubject $SUBJECTS_DIR/fsaverage --srclabel $PROB_MAP_DIR/rh.HCP_LPC_PROB_MPM_0.20_$PROB_MAP.label --trgsubject $SUBJECTS_DIR/$TRG_SUB --trglabel $SUBJECTS_DIR/$TRG_SUB/label/rh.${PROB_MAP}_MPM.label --regmethod surface

done 

done