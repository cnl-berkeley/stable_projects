## Projected Labels
This pipeline sulcal maximum probability maps (MPMs) to new surfaces
- mri_label2label.sh: Run this code to project probability maps from fsaverage onto individual surfaces.
- '?h.HCP_LPC_PROB_MPM_0.20_(sulcus).label' = heatmap version of sulcal MPM
- '?h.HCP_LPC_PROB_MPM_binary_0.20_(sulcus).label' = binarized version of sulcal MPM 
- '?h.HCP_LPC_PROB_(sulcus).label' = unthresholded sulcal probability map

## Citations
- Bulk of code written by [Jacob Miller](https://osf.io/7fwqk/), with edits from Benjamin Parker and Ethan Willbrand.